All the code is ParticleSwarnOptimization.fs

Script.fsx contains example usage
